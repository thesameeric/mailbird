<?php

namespace App\Http\Controllers;
use App\Mail\welcomeMail;
use Illuminate\Support\Facades\Mail;

use Illuminate\Http\Request;

class mailController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

     /**
     * Processes mail requests
     *
     * @return void
     */
    public function index(Request $request) {
    }

    public function send()
    {
        $objDemo = new \stdClass();
        $objDemo->demo_one = 'Demo One Value';
        $objDemo->demo_two = 'Demo Two Value';
        $objDemo->sender = 'DSCFUTA';
        $objDemo->receiver = 'Okiti';
 
        Mail::to("osivwiokiti@gmail.com")->send(new welcomeMail($objDemo));
    }
}
