Hello <i><?php echo e($demo->receiver); ?></i>,
<p>This is a demo email for testing purposes! Also, it's the HTML version.</p>
   
Thank You,
<br/>
<i><?php echo e($demo->sender); ?></i><?php /**PATH C:\xampp\htdocs\mailservice\mailservice\resources\views/mails/demo.blade.php ENDPATH**/ ?>