Hello <i>{{ $demo->receiver }}</i>,
<p>This is a demo email for testing purposes! Also, it's the HTML version.</p>
   
Thank You,
<br/>
<i>{{ $demo->sender }}</i>